ROTA 99 — APK LOCAL

Este projeto Android abre o dashboard HTML empacotado no próprio aplicativo. Não usa nuvem, hospedagem ou permissões de internet. Os registros são guardados no armazenamento local do WebView.

COMO GERAR O APK:
1. Abra a pasta do projeto no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Vá em Build > Build Bundle(s) / APK(s) > Build APK(s).
4. O APK de teste costuma ficar em app/build/outputs/apk/debug/app-debug.apk.
5. Transfira esse APK para o Android e permita a instalação desta fonte, se o aparelho solicitar.

IMPORTANTE:
Este ZIP é o projeto-fonte Android, não um APK já compilado. A compilação exige Android Studio/SDK e Gradle. Não há conexão com a internet configurada no app.
